import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { MusicServiceService } from '../music-service.service';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchStr:string;
  musicArray = [];
  artistName : String;
  constructor(private _musicSerivice:MusicServiceService) { }

  ngOnInit() {
    
  }
  searchForm = new FormGroup({
      search : new FormControl('Search here'),
  });
  onSubmit(){
     this._musicSerivice.searchMusic(this.searchStr).subscribe( result =>
      {
        this.musicArray = result.json();
        this.musicArray = this.musicArray["results"];
        this.artistName = this.musicArray[0].artistName;
        console.log(this.musicArray[0]);
      }
     
    );

      
    
     
  }
  
}
