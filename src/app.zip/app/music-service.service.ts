import { Injectable } from '@angular/core';
import { Http,Headers } from '@angular/http';
@Injectable({
  providedIn: 'root'
})
export class MusicServiceService {
  searchURL:string;
  constructor(private _http:Http,) { }

  searchMusic(str:string,type='artist'){
    return this._http.get("https://devru-gaana-v1.p.mashape.com/search.php?term="+str)
    .header("X-Mashape-Key", "wydRO7blJSmshZqZVcu0ODx503zJp1iyTw8jsnJ1c4qFzKLES1")
    .header("Accept", "application/json")
    .end(function (result) {
      console.log(result.status, result.headers, result.body);
    });

  }

}
